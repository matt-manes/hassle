# Changelog

## 2.0.1 (2023-02-18)

#### Fixes

* change load_template to load_config
* fix project.urls in pyproject template


## v2.0.0 (2023-02-18)

#### Others

* build v2.0.0